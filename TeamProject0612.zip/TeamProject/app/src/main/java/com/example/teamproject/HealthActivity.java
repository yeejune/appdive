package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.HashMap;
import java.util.Map;

public class HealthActivity extends AppCompatActivity {

    private Map<Button, String> buttonUrlMap = new HashMap<>(); // 버튼과 URL 매핑
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health);
        back = findViewById(R.id.buttonback);


        setupButtonUrlMap(); // 버튼과 URL 매핑 설정
        setupButtonListeners(); // 버튼 리스너 설정
    }

    private void setupButtonUrlMap() {
        buttonUrlMap.put(findViewById(R.id.arm), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%ED%9B%88%EB%A0%A8-%ED%9B%84-%ED%8C%94%EC%9D%84-%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD%ED%95%98%EB%8A%94-%EB%B0%A9%EB%B2%95/");
        // ^ 팔 ^
        buttonUrlMap.put(findViewById(R.id.leg), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%EC%A0%84%EB%B0%A9%EC%8B%AD%EC%9E%90%EC%9D%B8%EB%8C%80-%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/");
        // ^ 다리 ^
        buttonUrlMap.put(findViewById(R.id.waist), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%ED%97%88%EB%A6%AC%ED%86%B5%EC%A6%9D%EC%9D%84-%EC%98%88%EB%B0%A9%ED%95%98%EB%8A%94-%EC%9A%B4%EB%8F%99/");
        // ^ 허리 ^
        buttonUrlMap.put(findViewById(R.id.neck), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%EB%AA%A9-%EA%B5%AC%EC%B6%95%EC%9D%84-%EC%98%88%EB%B0%A9%ED%95%98%EA%B8%B0-%EC%9C%84%ED%95%9C-%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD-%EC%9A%B4%EB%8F%99/");
        // ^ 목 ^
        buttonUrlMap.put(findViewById(R.id.shoulder), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%EC%8A%B9%EB%AA%A8%EA%B7%BC-%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/");
        // ^ 어깨 ^
        buttonUrlMap.put(findViewById(R.id.ankle), "https://lifestyle.fit/ko/%ED%9B%88%EB%A0%A8/%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD/%EC%86%90%EB%AA%A9-%EA%B1%B4%EC%97%BC-%EC%9A%B4%EB%8F%99/");
        // ^ 손목,발목 ^
    }

    private void setupButtonListeners() {
        for (Map.Entry<Button, String> entry : buttonUrlMap.entrySet()) {
            Button button = entry.getKey();
            String url = entry.getValue();

            button.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            });
        }
        back.setOnClickListener(v -> finish());
    }
}