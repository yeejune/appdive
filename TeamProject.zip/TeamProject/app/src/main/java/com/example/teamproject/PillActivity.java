package com.example.teamproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PillActivity extends AppCompatActivity {
    private TimePicker timePicker;
    private TextView timer1, timer2, timer3;
    private int hour, min;
    private Button setTime;
    private RadioButton ra1, ra2, ra3;
    private int Radioint;

    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pill);

        Button pillback =(Button)findViewById(R.id.pillbackbutton);
        pillback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        initTime();

        timePicker = findViewById(R.id.timepicker);
        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {

            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                min = minute;
            }
        });


        ra1 = (RadioButton)findViewById(R.id.Radio1);
        ra1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Radioint = 1;
            }
        });
        ra2 = (RadioButton)findViewById(R.id.Radio2);
        ra2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Radioint = 2;
            }
        });
        ra3 = (RadioButton)findViewById(R.id.Radio3);
        ra3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Radioint = 3;
            }
        });



        setTime=(Button)findViewById(R.id.buttonSetTimer);
        setTime.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if(Radioint == 1){
                    timer1.setText(new StringBuilder().append("알람 시간:" ).append(hour).append("시 : ").append(min).append("분"));
                } else if (Radioint == 2) {
                    timer2.setText(new StringBuilder().append("알람 시간:" ).append(hour).append("시 : ").append(min).append("분"));
                } else if (Radioint == 3) {
                    timer3.setText(new StringBuilder().append("알람 시간:" ).append(hour).append("시 : ").append(min).append("분"));
                }
            }
        });
    }

    private void initTime(){
        timer1 = findViewById(R.id.timer1);
        timer2 = findViewById(R.id.timer2);
        timer3 = findViewById(R.id.timer3);
    }





}