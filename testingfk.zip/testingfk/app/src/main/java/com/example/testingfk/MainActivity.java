package com.example.testingfk;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentActivity;


import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.io.IOException;
import java.util.List;

    public class MainActivity extends FragmentActivity implements OnMapReadyCallback {
        private GoogleMap mMap;
        private Geocoder geocoder;
        private EditText editText;
        private Button button;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            editText = findViewById(R.id.editText);
            button = findViewById(R.id.button);

            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        }

        @Override
        public void onMapReady(final GoogleMap googleMap) {
            mMap = googleMap;
            geocoder = new Geocoder(this);

            // 버튼 클릭 시 주소를 검색하여 해당 위치를 지도에 표시
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String address = editText.getText().toString();
                    List<Address> addressList = null;

                    try {
                        addressList = geocoder.getFromLocationName(address, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    if (addressList != null && !addressList.isEmpty()) {
                        String latitude;
                        Address resultAddress = addressList.get(0);
                        LatLng location = new LatLng(resultAddress.getLatitude(), resultAddress.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(location).title(address));
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15));

                    }
                }
            });
        }
    }
/*
        private void searchHospitals(double latitude, double longitude) {
            // 사용할 API 키 입력
            String apiKey = "AIzaSyAJXCpc21Wjh8axWVvqxadDI_OUy8Djs_M";

            // API 호출 URL 구성
            String url =

        }
    }





/*

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION_PERMISSION = 100;
    private FusedLocationProviderClient fusedLocationClient;
    private ListView listView;
    private List<String> hospitalNames = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, hospitalNames);
        listView.setAdapter(adapter);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
            } else {
                getLastLocation();
            }
        } else {
            getLastLocation();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                // 사용자가 위치 권한을 거부한 경우 처리
            }
        }
    }



        // 실제 API 호출 및 응답 처리 코드 작성
        // ...

        // 병원 정보 파싱 및 ListView에 추가
        // ...
    }

